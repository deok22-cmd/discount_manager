-- 데이터베이스 생성 (가정: 기존 DB 사용 또는 신규 생성)
CREATE DATABASE IF NOT EXISTS bitnami_discount;
USE bitnami_discount;

-- 1. 이벤트 테이블
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    description TEXT,
    discount_value INT DEFAULT 0,
    valid_days INT DEFAULT 30,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 할인권 테이블
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    coupon_code VARCHAR(10) UNIQUE NOT NULL,
    customer_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    status ENUM('ISSUED', 'USED', 'EXPIRED') DEFAULT 'ISSUED',
    expiration_date DATE NOT NULL,
    issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    used_at DATETIME NULL,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 초기 이벤트 데이터 (예시)
INSERT INTO events (event_name, description, discount_value, valid_days) 
VALUES ('헬레녹스 장비 렌탈 고객 텐트세탁 할인', '헬레녹스 렌탈 고객 대상 5,000원 할인권', 5000, 30);
